<?php

/**
 * Copyright 2020-2022 LiTEK
 *      ____  _        __        __
 *    / ___|| | ___   \ \      / /_ _ _ __ ___
 *   \___ \| |/ / | | \ \ /\ / / _` | '__/ __|
 *   ___) |   <| |_| |\ V  V / (_| | |  \__ \
 * |____/|_|\_\\__, | \_/\_/ \__,_|_|  |___/
 *             |___/
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
declare(strict_types=1);
namespace SkyWarsPC\Command;


use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\command\PluginIdentifiableCommand;
use pocketmine\Player;
use pocketmine\plugin\Plugin;
use pocketmine\Server;
use SkyWarsPC\Arena\ArenaManager;
use SkyWarsPC\Data\Database;
use SkyWarsPC\Entity\EntityManager;
use SkyWarsPC\Entity\types\JoinEntity;
use SkyWarsPC\Entity\types\TopsEntity;
use SkyWarsPC\SkyWars;

class SkyWarsCommand extends Command implements PluginIdentifiableCommand
{
	/**
	 * SkyWarsCommand constructor.
	 */
	public function __construct()
	{
		parent::__construct('skywars', 'skywars help', 'skywars help', ['skywars', 'sw']);
	}

	/**
	 * @param CommandSender $sender
	 * @param string $commandLabel
	 * @param array $args
	 * @return mixed|void
	 */
	public function execute(CommandSender $sender, string $commandLabel, array $args)
	{
		if ($sender instanceof Player) {
			if (isset($args[0])) {
				switch ($args[0]) {
					case 'help':
						if ($sender->isOp()) {
							$sender->sendMessage(
								'§8-=[§a+§8]=- [' . SkyWars::PREFIX . '§8] -=[§a+§8]=-' . "\n" .
								'§e/sw help - §7Obtain help about the plugin' . "\n" .
								'§e/sw create {arenaName} {levelName} - §7Create new arena' . "\n" .
								'§e/sw delete {arenaName} - §7Delete a skywars arena' . "\n" .
								'§e/sw reconfigure {arenaName} - §7Reconfigure arena data' . "\n" .
								'§e/sw exit - §7Leave a game.' . "\n" .
								'§e/sw npc - §7Spawn the join entity' . "\n" .
								'§e/sw tops - §7Place the skywars scoreboard' . "\n" .
								'§8-=[§a+§8]=- [' . SkyWars::PREFIX . '§8] -=[§a+§8]=-'
							);
						}
						break;
					case 'create':
						if (!$sender->hasPermission('sw.command.create')) {
							$sender->sendMessage(SkyWars::LOG_PREFIX . '§cYou can\'t use this command.');
							return true;
						}
						if (!isset($args[1], $args[2])) {
							$sender->sendMessage(SkyWars::LOG_PREFIX . '§cUsage: §7/sw create §e{arenaName} {levelName}.');
							return true;
						}
						if (ArenaManager::isValidArena($args[2])) {
							$sender->sendMessage(SkyWars::LOG_PREFIX . '§cThe arena already exists.');
							return true;
						}
						if (!Server::getInstance()->isLevelGenerated($args[2])) {
							return;
						}
						if (Server::getInstance()->isLevelGenerated($args[2])) {
							Server::getInstance()->loadLevel($args[2]);
						}
						$sender->setGamemode(1);
						ArenaManager::createArena($sender, $args[1], Server::getInstance()->getLevelByName($args[2]));
						break;
					case 'reconfigure':
						if (!$sender->hasPermission('sw.command.reconfigure')) {
							$sender->sendMessage(SkyWars::LOG_PREFIX . '§cYou can\'t use this command.');
							return true;
						}
						if (!isset($args[1])) {
							$sender->sendMessage(SkyWars::LOG_PREFIX . '§cUsage: §7/sw reconfigure §e{levelName}.');
							return true;
						}
						if (!ArenaManager::isValidArena($args[1])) {
							$sender->sendMessage(SkyWars::LOG_PREFIX . '§cThe arena doesn\'t exists.');
							return true;
						}
						$sender->setGamemode(1);
						ArenaManager::reconfigureArena($sender, Server::getInstance()->getLevelByName($args[1]));
						break;
					case 'delete':
						if (!$sender->hasPermission('sw.command.delete')) {
							$sender->sendMessage(SkyWars::LOG_PREFIX . '§cYou can\'t use this command.');
							return true;
						}
						if (!isset($args[1])) {
							$sender->sendMessage(SkyWars::LOG_PREFIX . '§cUsage: §7/sw delete §e{levelName}.');
							return true;
						}
						if (!ArenaManager::isValidArena($args[1])) {
							$sender->sendMessage(SkyWars::LOG_PREFIX . '§cThe arena doesn\'t exists.');
							return true;
						}
						ArenaManager::deleteArena($args[1]);
						$sender->sendMessage(SkyWars::LOG_PREFIX . '§aArena §e' . $args[1] . ' §awas deleted!');
						break;
					case 'npc':
						if (!$sender->hasPermission('sw.command.npc')) {
							$sender->sendMessage(SkyWars::LOG_PREFIX . '§cYou can\'t use this command.');
							return true;
						}
						if (!$sender->getLevel() === Server::getInstance()->getDefaultLevel()) {
							$sender->sendMessage(SkyWars::LOG_PREFIX . '§cError, please teleport to default level!');
							return true;
							break;
						}
						if (isset($args[1]) && $args[1] === 'delete'){
							foreach (Server::getInstance()->getDefaultLevel()->getEntities() as $entity) {
								if ($entity instanceof JoinEntity){
									$entity->close();
									return;
								}
							}
						}
						EntityManager::setJoinEntity($sender);
						break;
					case 'tops':
						if (!$sender->hasPermission('sw.command.tops')) {
							$sender->sendMessage(SkyWars::LOG_PREFIX . '§cYou can\'t use this command.');
							return true;
						}
						if (!$sender->getLevel() === Server::getInstance()->getDefaultLevel()) {
							$sender->sendMessage(SkyWars::LOG_PREFIX . '§cError, please place tops in lobby!');
							return true;
							break;
						}
						if (isset($args[1]) && $args[1] === 'delete'){
							foreach (Server::getInstance()->getDefaultLevel()->getEntities() as $entity) {
								if ($entity instanceof TopsEntity){
									$entity->close();
									return;
								}
							}
						}
						EntityManager::setTopsEntity($sender);
						break;
					case 'join':
						if ($sender->isOp()) {
							$database = new Database();
							$database->addToDatabase($sender->getName());
							ArenaManager::joinArena($sender, $args[1]);
						}
						break;
					case 'kit':
						ArenaManager::setKit($sender,$args[1],$sender->getLevel()->getFolderName());
						$sender->sendMessage("Kit {$args[1]} elegido");
						break;
					default:
						$sender->sendMessage(SkyWars::LOG_PREFIX . '§cThat didn\'t work, try /sw help.');
						break;
				}
			} else {
				$sender->sendMessage(SkyWars::LOG_PREFIX . '§cThat didn\'t work, try /sw help.');
			}
		} else {
			$sender->sendMessage(SkyWars::LOG_PREFIX . '§cIt seems that you can\'t use this command here.');
		}
	}

	/**
	 * @return Plugin
	 */
	public function getPlugin(): Plugin
	{
		return SkyWars::$instance;
	}
}