<?php

/**
 * Copyright 2020-2022 LiTEK
 *      ____  _        __        __
 *    / ___|| | ___   \ \      / /_ _ _ __ ___
 *   \___ \| |/ / | | \ \ /\ / / _` | '__/ __|
 *   ___) |   <| |_| |\ V  V / (_| | |  \__ \
 * |____/|_|\_\\__, | \_/\_/ \__,_|_|  |___/
 *             |___/
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
declare(strict_types=1);
namespace SkyWarsPC;


use pocketmine\entity\Entity;
use pocketmine\Player;
use pocketmine\plugin\PluginBase;
use pocketmine\tile\Tile;
use SkyWarsPC\Arena\ArenaManager;
use SkyWarsPC\Command\SkyWarsCommand;
use SkyWarsPC\Data\Database;
use SkyWarsPC\Entity\object\BossBarObject;
use SkyWarsPC\Entity\types\JoinEntity;
use SkyWarsPC\Entity\types\TopsEntity;
use SkyWarsPC\Event\ArenaEvents;
use SkyWarsPC\Event\GlobalEvents;
use SkyWarsPC\Scheduler\GameTask;
use SkyWarsPC\Scheduler\UpdateJoinEntity;
use SkyWarsPC\Util\chest\Chest;
use SkyWarsPC\Util\PluginUtils;

define('PLUGIN_INFO','SkyWars Modular v1.0');

class SkyWars extends PluginBase
{
	/* @var Database */
	public $database;

	/* @var SkyWars */
	public static $instance;

	/* @const string LOG_PREFIX */
	public const LOG_PREFIX = '§7[§b§lSky§fWars§r§7] ';

	/* @const string PREFIX */
	public const PREFIX = '§b§lSky§fWars§r';

	/* @var array $configurators */
	public $configurators = [];

	/** @var BossBarObject */
	private static $boss;


	public function onEnable(): void
	{
		self::$instance = $this;
		self::$boss = new BossBarObject(PluginUtils::centerLine('SkyWars Data'), 100, 100);
		Tile::registerTile(Chest::class, ['Chest', 'minecraft:chest']);
		$this->registerEvents();
		$this->registerCommands();
		$this->makeDirectories();
		$this->registerEntities();
		ArenaManager::loadArenas();
		$this->initDatabase();
		$this->getScheduler()->scheduleRepeatingTask(new UpdateJoinEntity(), 40);
		$this->getScheduler()->scheduleRepeatingTask(new GameTask(), 20);
	}

	private function registerEvents(): void
	{
		$eventList = [new GlobalEvents(), new ArenaEvents()];
		foreach ($eventList as $event) {
			$this->getServer()->getPluginManager()->registerEvents($event, $this);
		}
		unset($eventList);
	}

	private function registerCommands(): void {
		$commandList = [new SkyWarsCommand()];
		foreach ($commandList as $command) {
			$this->getServer()->getCommandMap()->register('_cmd', $command);
		}
		unset($commandList);
	}

	private function registerEntities(): void {
		$entities = [JoinEntity::class,TopsEntity::class];
		foreach ($entities as $entity) {
			Entity::registerEntity($entity, true);
		}
		unset ($entities);
	}

	private function makeDirectories(): void {
		$directories = ['database','arenas','compressed'];
		foreach ($directories as $directory) {
			@mkdir($this->getDataFolder().$directory);
		}
		unset($directories);
	}


	public static function getInstance(): SkyWars {
		return self::$instance;
	}


	public function isConfigurator(Player $player): bool {
		return in_array($player->getName(),$this->configurators, true);
	}

	public static function getBossBar(): BossBarObject
	{
		return self::$boss;
	}

	private function initDatabase(): void
	{
		$this->getLogger()->info('§aSkyWars database connected.');
		$database = new Database();
		$database->createTable();
	}

	public function onDisable(): void
	{
		foreach ($this->getServer()->getOnlinePlayers() as $onlinePlayer) {
			$onlinePlayer->teleport($this->getServer()->getDefaultLevel()->getSafeSpawn());
		}
		$this->saveArenas();
	}

	public function saveArenas(): void
	{
		foreach (ArenaManager::getAllArenas() as $arena) {
			GameTask::reloadArena($arena);
			ArenaManager::resetArena($arena);
		}
	}
}