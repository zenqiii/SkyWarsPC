<?php

/**
 * Copyright 2020-2022 LiTEK
 *      ____  _        __        __
 *    / ___|| | ___   \ \      / /_ _ _ __ ___
 *   \___ \| |/ / | | \ \ /\ / / _` | '__/ __|
 *   ___) |   <| |_| |\ V  V / (_| | |  \__ \
 * |____/|_|\_\\__, | \_/\_/ \__,_|_|  |___/
 *             |___/
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
declare(strict_types=1);
namespace SkyWarsPC\Data;

use SkyWarsPC\SkyWars;
use SQLite3;

define('DATABASE_PATH', SkyWars::$instance->getDataFolder() . 'database' . DIRECTORY_SEPARATOR . 'database.sq3');

class Database
{
	/** @var string */
	public const DATABASE_PATH = DATABASE_PATH;

	/**
	 * @return SQLite3
	 */
	public function getDatabase(): SQLite3 {
		return new SQLite3(self::DATABASE_PATH, SQLITE3_OPEN_READWRITE | SQLITE3_OPEN_CREATE,'PlanetCraft');
	}

	/**
	 * Create tables for database
	 */
	public function createTable(): void
	{
		$this->getDatabase()->exec('CREATE TABLE IF NOT EXISTS Players (
            NAME TEXT NOT NULL,
            WON_MATCHES INT NOT NULL,
            UNIQUE(NAME)
        )');
	}

	/**
	 * @param string $player
	 * @return bool
	 */
	public function playerInDatabase(string $player): bool
	{

		$query = $this->getDatabase()->querySingle("SELECT NAME FROM Players WHERE NAME = '$player'");
		return !($query === null);
	}

	/**
	 * @param string $player
	 */
	public function addToDatabase(string $player): void
	{
		$sql = $this->getDatabase()->prepare('INSERT OR IGNORE INTO Players(NAME,WON_MATCHES) SELECT :name, :won_matches WHERE NOT EXISTS(SELECT * FROM Players WHERE NAME = :name);');
		$sql->bindValue(':name', $player, SQLITE3_TEXT);
		$sql->bindValue(':won_matches', 0, SQLITE3_NUM);
		$sql->execute();
	}

	/**
	 * @param string $player
	 */
	public function setWonMatch(string $player): void
	{
		$won_matches = $this->getWonMatches($player);
		$result = $won_matches + 1;
		$this->getDatabase()->exec("UPDATE Players SET WON_MATCHES='$result' WHERE NAME='$player'");
	}

	/**
	 * @param string $player
	 * @return mixed
	 */
	public function getWonMatches(string $player)
	{
		return $this->getDatabase()->querySingle("SELECT WON_MATCHES FROM Players WHERE NAME = '$player'");
	}

	/**
	 * @return string
	 */
	public function getTops(): string
	{
		$leaderboard = [];
		$result = $this->getDatabase()->query('SELECT NAME, WON_MATCHES FROM Players ORDER BY WON_MATCHES DESC LIMIT 10');
		$number = 0;
		while ($row = $result->fetchArray(SQLITE3_ASSOC)) {
			$leaderboard[$number++] = $row;
		}
		$count = count($leaderboard);
		$break = "\n";
		if ($count > 0) {
			$top1 = '§11. §3Name§7: §e' . $leaderboard[0]['NAME'] . '  §cWins§7: §b' . $leaderboard[0]['WON_MATCHES'];
		} else {
			$top1 = '';
		}
		if ($count > 1) {
			$top2 = '§12. §3Name§7: §e' . $leaderboard[1]['NAME'] . '  §cWins§7: §b' . $leaderboard[1]['WON_MATCHES'];
		} else {
			$top2 = '';
		}
		if ($count > 2) {
			$top3 = '§13. §3Name§7: §e' . $leaderboard[2]['NAME'] . '  §cWins§7: §b' . $leaderboard[2]['WON_MATCHES'];
		} else {
			$top3 = '';
		}
		if ($count > 3) {
			$top4 = '§14. §3Name§7: §e' . $leaderboard[3]['NAME'] . '  §cWins§7: §b' . $leaderboard[3]['WON_MATCHES'];
		} else {
			$top4 = '';
		}
		if ($count > 4) {
			$top5 = '§15. §3Name§7: §e' . $leaderboard[4]['NAME'] . '  §cWins§7: §b' . $leaderboard[4]['WON_MATCHES'];
		} else {
			$top5 = '';
		}
		if ($count > 5) {
			$top6 = '§16. §3Name§7: §e' . $leaderboard[5]['NAME'] . '  §cWins§7: §b' . $leaderboard[5]['WON_MATCHES'];
		} else {
			$top6 = '';
		}
		if ($count > 6) {
			$top7 = '§17. §3Name§7: §e' . $leaderboard[6]['NAME'] . '  §cWins§7: §b' . $leaderboard[6]['WON_MATCHES'];
		} else {
			$top7 = '';
		}
		if ($count > 7) {
			$top8 = '§18. §3Name§7: §e' . $leaderboard[7]['NAME'] . '  §cWins§7: §b' . $leaderboard[7]['WON_MATCHES'];
		} else {
			$top8 = '';
		}
		if ($count > 8) {
			$top9 = '§19. §3Name§7: §e' . $leaderboard[8]['NAME'] . '  §cWins§7: §b' . $leaderboard[8]['WON_MATCHES'];
		} else {
			$top9 = '';
		}
		if ($count > 9) {
			$top10 = '§110. §3Name§7: §e' . $leaderboard[9]['NAME'] . '  §cWins§7: §b' . $leaderboard[9]['WON_MATCHES'];
		} else {
			$top10 = '';
		}
		return SkyWars::PREFIX . "\n§r§aLeaderboard\n" .  $top1 . $break . $top2 . $break . $top3 . $break . $top4 . $break . $top5 . $break . $top6 . $break . $top7 . $break . $top8 . $break . $top9 . $break . $top10;
	}
}