<?php

/**
 * Copyright 2020-2022 LiTEK
 *      ____  _        __        __
 *    / ___|| | ___   \ \      / /_ _ _ __ ___
 *   \___ \| |/ / | | \ \ /\ / / _` | '__/ __|
 *   ___) |   <| |_| |\ V  V / (_| | |  \__ \
 * |____/|_|\_\\__, | \_/\_/ \__,_|_|  |___/
 *             |___/
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
declare(strict_types=1);

namespace SkyWarsPC\Util\chest;

use pocketmine\item\Armor;
use pocketmine\item\Axe;
use pocketmine\item\Bow;
use pocketmine\item\Bucket;
use pocketmine\item\enchantment\Enchantment;
use pocketmine\item\enchantment\EnchantmentInstance;
use pocketmine\item\ItemFactory;
use pocketmine\item\ItemIds;
use pocketmine\item\Potion;
use pocketmine\item\SplashPotion;
use pocketmine\item\Sword;
use pocketmine\level\Level;
use pocketmine\tile\Chest;
use function count;
use function random_int;
use function shuffle;

class ChestContent
{
    public static function getChestContent(): array
    {
        return array(//ARMOR
            'armor' => array(
                ItemIds::LEATHER_CAP,
                ItemIds::LEATHER_TUNIC,
                ItemIds::LEATHER_PANTS,
                ItemIds::LEATHER_BOOTS,

                ItemIds::GOLD_HELMET,
                ItemIds::GOLD_CHESTPLATE,
                ItemIds::GOLD_LEGGINGS,
                ItemIds::GOLD_BOOTS,

                ItemIds::CHAIN_HELMET,
                ItemIds::CHAIN_CHESTPLATE,
                ItemIds::CHAIN_LEGGINGS,
                ItemIds::CHAIN_BOOTS,

                ItemIds::IRON_HELMET,
                ItemIds::IRON_CHESTPLATE,
                ItemIds::IRON_LEGGINGS,
                ItemIds::IRON_BOOTS,
            ), //WEAPONS
            'weapon' => array(
                ItemIds::WOODEN_AXE,
                ItemIds::GOLD_AXE,
                ItemIds::STONE_AXE,
                ItemIds::IRON_AXE,

                ItemIds::WOODEN_SWORD,
                ItemIds::GOLD_SWORD,
                ItemIds::STONE_SWORD,
                ItemIds::IRON_SWORD,

                ItemIds::STONE_PICKAXE
            ), //FOOD
            'food' => array(
                ItemIds::RAW_PORKCHOP,
                ItemIds::RAW_CHICKEN,
                ItemIds::MELON_SLICE,
                ItemIds::COOKIE,
                ItemIds::RAW_BEEF,
                ItemIds::CARROT,
                ItemIds::APPLE,
                ItemIds::GOLDEN_APPLE,
                ItemIds::BREAD,
                ItemIds::BAKED_POTATO,
                ItemIds::COOKED_CHICKEN,
                ItemIds::COOKED_PORKCHOP,
                ItemIds::STEAK
            ), //THROWABLE
            'throwable' => array(
                ItemIds::SNOWBALL,
                ItemIds::EGG,
                ItemIds::ARROW
            ), //BLOCKS
            'block' => array(
                ItemIds::STONE,
                ItemIds::WOODEN_PLANKS,
                ItemIds::COBBLESTONE,
                ItemIds::DIRT
            ), //OTHER
            'other' => array(
                ItemIds::POTION,
                ItemIds::FISHING_ROD,
                ItemIds::SPLASH_POTION,
                ItemIds::BUCKET,
                ItemIds::TNT,
                ItemIds::COMPASS,
            )
        );
    }

    public static function getMiddleChestContent(): array
    {
        return array(//ARMOR
            'armor' => array(
                ItemIds::IRON_HELMET,
                ItemIds::IRON_CHESTPLATE,
                ItemIds::IRON_LEGGINGS,
                ItemIds::IRON_BOOTS,

                ItemIds::DIAMOND_HELMET,
                ItemIds::DIAMOND_CHESTPLATE,
                ItemIds::DIAMOND_LEGGINGS,
                ItemIds::DIAMOND_BOOTS
            ), //WEAPONS
            'weapon' => array(
                ItemIds::IRON_AXE,
                ItemIds::DIAMOND_AXE,

                ItemIds::IRON_SWORD,
                ItemIds::DIAMOND_SWORD,

                ItemIds::DIAMOND_PICKAXE
            ), //FOOD
            'food' => array(
                ItemIds::RAW_PORKCHOP,
                ItemIds::RAW_CHICKEN,
                ItemIds::MELON_SLICE,
                ItemIds::COOKIE,
                ItemIds::RAW_BEEF,
                ItemIds::CARROT,
                ItemIds::APPLE,
                ItemIds::GOLDEN_APPLE,
                ItemIds::BREAD,
                ItemIds::BAKED_POTATO,
                ItemIds::COOKED_CHICKEN,
                ItemIds::COOKED_PORKCHOP,
                ItemIds::STEAK
            ), //THROWABLE
            'throwable' => array(
                ItemIds::SNOWBALL,
                ItemIds::EGG,
                ItemIds::ARROW
            ), //BLOCKS
            'block' => array(
                ItemIds::STONE,
                ItemIds::WOODEN_PLANKS,
                ItemIds::COBBLESTONE,
                ItemIds::DIRT
            ), //OTHER
            'other' => array(
                ItemIds::ENDER_PEARL,
                ItemIds::FISHING_ROD,
                ItemIds::POTION,
                ItemIds::SPLASH_POTION,
                ItemIds::BUCKET,
                ItemIds::TNT,
                ItemIds::COMPASS,
            )
        );
    }

    public static function refillChests(Level $arena, $insane = false): void
    {
        $islandItems = self::getChestContent();
        $middleItems = self::getMiddleChestContent();

        foreach ($arena->getTiles() as $tile) {
            if ($tile instanceof Chest) {
                $tile->getInventory()->clearAll();
                $contents = [];

                if ($tile->maxPlainDistance($arena->getSpawnLocation()) <= 15) {
                    $items = $middleItems;
                } else {
                    $items = $islandItems;
                }

                $contents[] = ItemFactory::get($items['armor'][random_int(0, count($items['armor']) - 1)]);

                if (random_int(0, 2)) {
                    $contents[] = ItemFactory::get($items['armor'][random_int(0, count($items['armor']) - 1)]);
                }

                $contents[] = ItemFactory::get($items['weapon'][random_int(0, count($items['weapon']) - 1)]);

                $contents[] = ItemFactory::get($items['food'][random_int(0, count($items['food']) - 1)], 0, random_int(2, 5));

                $contents[] = ItemFactory::get($items['block'][random_int(0, count($items['block']) - 1)], 0, random_int(20, 64));

                switch (random_int(0, 3)) {
                    case 0:
                        $contents[] = ItemFactory::get($items['throwable'][random_int(0, count($items['throwable']) - 1)], 0, random_int(2, 5));
                        $contents[] = ItemFactory::get($items['other'][random_int(0, count($items['other']) - 1)]);
                        break;
                    case 1:
                        $contents[] = ItemFactory::get($items['throwable'][random_int(0, count($items['throwable']) - 1)], 0, random_int(2, 5));
                        break;
                    case 2:
                        $contents[] = ItemFactory::get($items['other'][random_int(0, count($items['other']) - 1)]);
                        break;
                    case 3:
                        $contents[] = ItemFactory::get(ItemIds::BOW);
                        $contents[] = ItemFactory::get(ItemIds::ARROW, 0, 15);
                        break;
                }

                shuffle($contents);

                $fcontent = [];

                $min = 0;
                $max = 3;
                foreach ($contents as $content) {
                    $fcontent[random_int($min, $max)] = $content;
                    $min += 3;
                    $max += 3;
                }

                foreach ($fcontent as $key => $item) {
                        if ($item instanceof Bucket) {
                        switch (random_int(0, 1)) {
                            case 0:
                                $item = ItemFactory::get(ItemIds::BUCKET, 10);
                                break;
                            case 1:
                                $item = ItemFactory::get(ItemIds::BUCKET, 8);
                                break;
                        }
                    } elseif ($item instanceof SplashPotion) {
                        switch (random_int(0, 8)) {
                            case 0:
                                $item = ItemFactory::get(ItemIds::SPLASH_POTION, Potion::SWIFTNESS);
                                break;
                            case 1:
                                $item = ItemFactory::get(ItemIds::SPLASH_POTION, Potion::HEALING);
                                break;
                            case 2:
                                $item = ItemFactory::get(ItemIds::SPLASH_POTION, Potion::REGENERATION);
                                break;
                            case 3:
                                $item = ItemFactory::get(ItemIds::SPLASH_POTION, Potion::STRENGTH);
                                break;
                            case 4:
                                $item = ItemFactory::get(ItemIds::SPLASH_POTION, Potion::LEAPING);
                                break;
                            case 5:
                                $item = ItemFactory::get(ItemIds::SPLASH_POTION, Potion::SLOWNESS);
                                break;
                            case 6:
                                $item = ItemFactory::get(ItemIds::SPLASH_POTION, Potion::WEAKNESS);
                                break;
                            case 7:
                                $item = ItemFactory::get(ItemIds::SPLASH_POTION, Potion::POISON);
                                break;
                            case 8:
                                $item = ItemFactory::get(ItemIds::SPLASH_POTION, Potion::FIRE_RESISTANCE);
                                break;
                        }
                    } elseif ($item instanceof Potion) {
                        switch (random_int(0, 4)) {
                            case 0:
                                $item = ItemFactory::get(ItemIds::POTION, Potion::SWIFTNESS);
                                break;
                            case 1:
                                $item = ItemFactory::get(ItemIds::POTION, Potion::HEALING);
                                break;
                            case 2:
                                $item = ItemFactory::get(ItemIds::POTION, Potion::REGENERATION);
                                break;
                            case 3:
                                $item = ItemFactory::get(ItemIds::POTION, Potion::STRENGTH);
                                break;
                            case 4:
                                $item = ItemFactory::get(ItemIds::POTION, Potion::LEAPING);
                                break;
                        }
                    } elseif ($insane || random_int(0, 2) === 2) {
                        if ($item instanceof Sword || $item instanceof Axe) {
                            if ($item->getId() !== ItemIds::DIAMOND_SWORD) {
                                $enchantment = Enchantment::getEnchantment(Enchantment::SHARPNESS);
                                if ($insane) {
                                    $rand = random_int(1, 3);
                                } else {
                                    $rand = 1;
                                }
                                $item->addEnchantment(new EnchantmentInstance($enchantment, $rand));
                            }
                        } elseif ($item instanceof Armor) {
                            $enchantment = Enchantment::getEnchantment(Enchantment::PROTECTION);
                            if ($insane) {
                                $rand = random_int(1, 2);
                            } else {
                                $rand = 1;
                            }
                            $item->addEnchantment(new EnchantmentInstance($enchantment, $rand));
                        } elseif ($item instanceof Bow) {
                            switch (random_int(0, 2)) {
                                case 0:
                                    $enchantment = Enchantment::getEnchantment(Enchantment::POWER);
                                    if ($insane) {
                                        $rand = random_int(1, 3);
                                    } else {
                                        $rand = 1;
                                    }
                                    $item->addEnchantment(new EnchantmentInstance($enchantment, $rand));
                                    break;
                                case 1:
                                    $enchantment = Enchantment::getEnchantment(Enchantment::PUNCH);
                                    $item->addEnchantment(new EnchantmentInstance($enchantment, 1));
                                    break;
                                case 2:
                                    $enchantment = Enchantment::getEnchantment(Enchantment::INFINITY);
                                    $item->addEnchantment(new EnchantmentInstance($enchantment, 1));
                                    break;
                            }

                        }
                    }

                    $tile->getInventory()->setItem($key, $item);
                }
            }
        }
    }
}