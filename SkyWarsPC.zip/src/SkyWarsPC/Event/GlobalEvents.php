<?php

/**
 * Copyright 2020-2022 LiTEK
 *      ____  _        __        __
 *    / ___|| | ___   \ \      / /_ _ _ __ ___
 *   \___ \| |/ / | | \ \ /\ / / _` | '__/ __|
 *   ___) |   <| |_| |\ V  V / (_| | |  \__ \
 * |____/|_|\_\\__, | \_/\_/ \__,_|_|  |___/
 *             |___/
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
declare(strict_types=1);
namespace SkyWarsPC\Event;


use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerChatEvent;
use pocketmine\event\player\PlayerMoveEvent;
use pocketmine\math\Vector2;
use pocketmine\network\mcpe\protocol\MoveActorAbsolutePacket;
use pocketmine\network\mcpe\protocol\MovePlayerPacket;
use pocketmine\Player;
use pocketmine\Server;
use SkyWarsPC\Arena\Arena;
use SkyWarsPC\Arena\ArenaManager;
use SkyWarsPC\Data\Database;
use SkyWarsPC\Entity\types\JoinEntity;
use SkyWarsPC\Entity\types\TopsEntity;
use SkyWarsPC\MathUtils\Vector3;
use SkyWarsPC\SkyWars;
use SkyWarsPC\Windows\FormManager;

class GlobalEvents implements Listener
{
	/**
	 * @param PlayerChatEvent $event
	 */
	public function onChat(PlayerChatEvent $event): void {
		$args = explode(' ',$event->getMessage());
		if (SkyWars::getInstance()->isConfigurator($event->getPlayer())){
			$event->setCancelled();
			switch ($args[0]) {
				case 'slots':
					if (isset($args[1])) {
						ArenaManager::setArenaDataIndex($event->getPlayer(), (int)$args[1], 'slots');
						$event->getPlayer()->sendMessage(SkyWars::LOG_PREFIX . '§aMaximum slots set in §e' . $args[1]);
					} else {
						$event->getPlayer()->sendMessage(SkyWars::LOG_PREFIX . '§cslots <int: maxSlots>');
						break;
					}
					break;
				case 'void':
					ArenaManager::setArenaDataIndex($event->getPlayer(), (string)(new Vector3($event->getPlayer()->x, $event->getPlayer()->y, $event->getPlayer()->z))->__toString(), 'void');
					$event->getPlayer()->sendMessage(SkyWars::LOG_PREFIX . '§aVoid configured in: §e' . "X:{$event->getPlayer()->x} Y:{$event->getPlayer()->y} Z:{$event->getPlayer()->z}");
					break;
				case 'enable':
					ArenaManager::setArenaDataIndex($event->getPlayer(), true, 'status');
					ArenaManager::setTime($event->getPlayer()->getLevel()->getFolderName(),'startTime',40);
					ArenaManager::setTime($event->getPlayer()->getLevel()->getFolderName(),'gameTime',20 * 60);
					ArenaManager::setTime($event->getPlayer()->getLevel()->getFolderName(),'endTime',10);
					ArenaManager::setArenaCycle($event->getPlayer()->getLevel()->getFolderName(), Arena::CYCLE_HUB);
					ArenaManager::compressArena($event->getPlayer()->getLevel()->getFolderName());
					$event->getPlayer()->sendMessage(SkyWars::LOG_PREFIX . '§aArena enabled! Teleporting to hub...');
					$event->getPlayer()->teleport(Server::getInstance()->getDefaultLevel()->getSafeSpawn());
					unset(SkyWars::getInstance()->configurators[array_search($event->getPlayer()->getName(), SkyWars::getInstance()->configurators, true)]);
					foreach (ArenaManager::getAllArenas() as $allArena) {
						if (!Server::getInstance()->isLevelLoaded($allArena)){
							Server::getInstance()->loadLevel($allArena);
						}
					}
					break;
				case 'respawn':
					ArenaManager::setArenaDataIndex($event->getPlayer(), (string)(new Vector3($event->getPlayer()->x, $event->getPlayer()->y, $event->getPlayer()->z))->__toString(), 'respawn');
					$event->getPlayer()->sendMessage(SkyWars::LOG_PREFIX . '§aSpectator spawnpoint configured');
					break;
				case 'spawn':
					if (ArenaManager::getMaxSlots($event->getPlayer()->getLevel()) === false) {
						$event->getPlayer()->sendMessage(SkyWars::LOG_PREFIX . '§cPlease configure maximum slots.');
						break;
					}
					if (!isset($args[1]) || !ctype_digit($args[1])) {
						$event->getPlayer()->sendMessage(SkyWars::LOG_PREFIX . '§cspawn <int: spawnNumber>');
						break;
					}
					if ((int)$args[1] <= 0){
						$event->getPlayer()->sendMessage(SkyWars::LOG_PREFIX . '§cFirst spawn need to be 1');
						break;
					}
					if (ArenaManager::getMaxSlots($event->getPlayer()->getLevel()) !== false){
						if ((int)$args[1] > ArenaManager::getMaxSlots($event->getPlayer()->getLevel())) {
							$event->getPlayer()->sendMessage(SkyWars::LOG_PREFIX . '§cYou have configured all slots!');
							break;
						}
					}
					ArenaManager::setArenaDataIndex($event->getPlayer(),(string)(new Vector3($event->getPlayer()->x,$event->getPlayer()->y,$event->getPlayer()->z))->__toString(), 'spawn', (int)$args[1]);
					$event->getPlayer()->sendMessage(SkyWars::LOG_PREFIX . '§aConfigured slot §e'.$args[1]);
					break;
				case 'help':
				default:
					$event->getPlayer()->sendMessage(
						'§8-=[§a+§8]=- [' . SkyWars::PREFIX . 'Help §8] -=[§a+§8]=-' . "\n" .
						'§ehelp - §7Obtain help about the arena configuration' . "\n" .
						'§eslots <int: maxSlots> - §7Set the maximum slots' . "\n" .
						'§espawn <int: spawnNumber> - §7Configure player spawnpoint' . "\n" .
						'§evoid - §7configure the minimum arena void' . "\n" .
						'§erespawn - §7Set respawn for spectators' . "\n" .
						'§eenable - §7Enable arena' . "\n" .
						'§8>-----=(§a+§8)=-----<'
					);
					break;
			}
		}
	}

	/**
	 * @param EntityDamageByEntityEvent $event
	 */
	public function onHit(EntityDamageByEntityEvent $event)
	{
		$damager = $event->getDamager();
		$entity = $event->getEntity();
		$database = new Database();
		if ($damager instanceof Player && $entity instanceof JoinEntity) {
			$event->setCancelled(true);
			FormManager::sendGameInformation($damager);
			if (!$database->playerInDatabase($damager->getName())){
				$database->addToDatabase($damager->getName());
			}
		} elseif ($damager instanceof Player && $entity instanceof TopsEntity){
			$event->setCancelled(true);
		}
	}


	/**
	 * @param PlayerMoveEvent $ev
	 */
	public function onPlayerMove(PlayerMoveEvent $ev) {
		$player = $ev->getPlayer();
		$from = $ev->getFrom();
		$to = $ev->getTo();
		if($from->distance($to) < 0.1) {
			return;
		}
		foreach ($player->getLevel()->getNearbyEntities($player->getBoundingBox()->expandedCopy(5, 5, 5), $player) as $e) {
			if($e instanceof Player) {
				continue;
			}
			$xdiff = $player->x - $e->x;
			$zdiff = $player->z - $e->z;
			$angle = atan2($zdiff, $xdiff);
			$yaw = (($angle * 180) / M_PI) - 90;
			$ydiff = $player->y - $e->y;
			$v = new Vector2($e->x, $e->z);
			$dist = $v->distance($player->x, $player->z);
			$angle = atan2($dist, $ydiff);
			$pitch = (($angle * 180) / M_PI) - 90;

			if($e instanceof JoinEntity) {
				$pk = new MovePlayerPacket();
				$pk->entityRuntimeId = $e->getId();
				$pk->position = $e->asVector3()->add(0, $e->getEyeHeight(), 0);
				$pk->yaw = $yaw;
				$pk->pitch = $pitch;
				$pk->headYaw = $yaw;
				$pk->onGround = $e->onGround;
			} else {
				$pk = new MoveActorAbsolutePacket();
				$pk->entityRuntimeId = $e->getId();
				$pk->position = $e->asVector3();
				$pk->xRot = $pitch;
				$pk->yRot = $yaw;
				$pk->zRot = $yaw;
			}
			$player->dataPacket($pk);
		}
	}
}