<?php

/**
 * Copyright 2020-2022 LiTEK
 *      ____  _        __        __
 *    / ___|| | ___   \ \      / /_ _ _ __ ___
 *   \___ \| |/ / | | \ \ /\ / / _` | '__/ __|
 *   ___) |   <| |_| |\ V  V / (_| | |  \__ \
 * |____/|_|\_\\__, | \_/\_/ \__,_|_|  |___/
 *             |___/
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
declare(strict_types=1);
namespace SkyWarsPC\Event;


use pocketmine\block\Block;
use pocketmine\entity\Effect;
use pocketmine\entity\EffectInstance;
use pocketmine\event\block\BlockBreakEvent;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\event\entity\EntityLevelChangeEvent;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerDeathEvent;
use pocketmine\event\player\PlayerDropItemEvent;
use pocketmine\event\player\PlayerGameModeChangeEvent;
use pocketmine\event\player\PlayerInteractEvent;
use pocketmine\event\player\PlayerMoveEvent;
use pocketmine\event\player\PlayerQuitEvent;
use pocketmine\item\Item;
use pocketmine\level\Position;
use pocketmine\Player;
use pocketmine\Server;
use SkyWarsPC\Arena\Arena;
use SkyWarsPC\Arena\ArenaManager;
use SkyWarsPC\MathUtils\Vector3;
use SkyWarsPC\SkyWars;
use SkyWarsPC\Util\PluginUtils;
use SkyWarsPC\Windows\FormManager;

class ArenaEvents extends BaseEvent implements Listener
{
	/**
	 * @param PlayerQuitEvent $event
	 */
	public function onQuit(PlayerQuitEvent $event)
	{
		if (!ArenaManager::isValidArena($event->getPlayer()->getLevel()->getFolderName())) {
			return;
		}
		if (SkyWars::getInstance()->isConfigurator($event->getPlayer())){
			return;
		}
		ArenaManager::removePlayer($event->getPlayer()->getLevel()->getFolderName(), $event->getPlayer()->getName());
		ArenaManager::removeSpectator($event->getPlayer()->getLevel()->getFolderName(), $event->getPlayer()->getName());
		SkyWars::getBossBar()->hideFrom($event->getPlayer());
		ArenaManager::clearAll($event->getPlayer());
	}

	/**
	 * @param PlayerDeathEvent $event
	 */
	public function onDeath(PlayerDeathEvent $event)
	{
		if (!ArenaManager::isValidArena($event->getPlayer()->getLevel()->getFolderName())) {
			return;
		}
		if (SkyWars::getInstance()->isConfigurator($event->getPlayer())){
			return;
		}
		ArenaManager::removePlayer($event->getPlayer()->getLevel()->getFolderName(), $event->getPlayer()->getName());
		ArenaManager::removeSpectator($event->getPlayer()->getLevel()->getFolderName(), $event->getPlayer()->getName());
	}

	/**
	 * @param EntityLevelChangeEvent $event
	 */
	public function onChangeLevel(EntityLevelChangeEvent $event)
	{
		$player = $event->getEntity();
		$from = $event->getOrigin();
		if (!ArenaManager::isValidArena($from->getFolderName())) {
			return;
		}
		if ($player instanceof Player) {
			ArenaManager::removePlayer($from->getFolderName(), $player->getName());
		}
	}

	/**
	 * @param EntityDamageByEntityEvent $event
	 */
	public function onDamageByEntity(EntityDamageByEntityEvent $event)
	{
		$player = $event->getDamager();
		$victim = $event->getEntity();
		if (!ArenaManager::isValidArena($victim->getLevel()->getFolderName())) {
			return;
		}
		if ($player instanceof Player && $victim instanceof Player) {
			if ($event->getFinalDamage() > $victim->getHealth()) {
				$event->setCancelled(true);
				$this->adaptableDeath($victim, "§b{$player->getNameTag()} §7has killed you.", $player);
			}
		}
	}

	/**
	 * @param EntityDamageEvent $event
	 */
	public function onDamage(EntityDamageEvent $event): void
	{
		if (!ArenaManager::isValidArena($event->getEntity()->getLevel()->getFolderName())) {
			return;
		}
		$player = $event->getEntity();
		if ($player instanceof Player && ArenaManager::isPlaying($player)) {
			if (SkyWars::getInstance()->isConfigurator($player)){
				return;
			}
			if ($event->getFinalDamage() > $player->getHealth()) {
				$event->setCancelled(true);
				switch ($event->getCause()) {
					case EntityDamageEvent::CAUSE_DROWNING:
					case EntityDamageByEntityEvent::CAUSE_SUFFOCATION:
						$this->adaptableDeath($player, '§eYou have drowned');
						break;
					case EntityDamageEvent::CAUSE_VOID:
					case EntityDamageEvent::CAUSE_SUICIDE:
						$this->adaptableDeath($player, '§eYou have fallen into the void');
						break;
					case EntityDamageEvent::CAUSE_FIRE:
					case EntityDamageEvent::CAUSE_LAVA:
						$this->adaptableDeath($player, '§eYou have burned out');
						break;
					case EntityDamageEvent::CAUSE_BLOCK_EXPLOSION:
						$this->adaptableDeath($player, '§eYou have exploded');
						break;
					case EntityDamageEvent::CAUSE_PROJECTILE:
						$this->adaptableDeath($player, 'You have been shot');
						break;
					case EntityDamageEvent::CAUSE_MAGIC:
						$this->adaptableDeath($player, '§eYou have been attacked with magic');
						break;
					default:
						$this->adaptableDeath($player, '§eYou have dead');
						break;
				}
			}
		}
	}

	/**
	 * @param Player $victim
	 * @param string $deathCause
	 * @param Player|null $assassin
	 */
	protected function adaptableDeath(Player $victim, string $deathCause, Player $assassin = null)
	{
		if (count(ArenaManager::getAlive($victim->getLevel()->getFolderName())) != 1) {
			if ($victim->getGamemode() != 3) {
				$formManager = new FormManager();
				$victim->teleport(Position::fromObject(Vector3::fromString((string)ArenaManager::getArenaSettings($victim->getLevel()->getFolderName())->get('respawn'))));
				ArenaManager::removePlayer($victim->getLevel()->getFolderName(), $victim->getName());
				SkyWars::getBossBar()->hideFrom($victim);
				ArenaManager::addSpectator($victim->getLevel()->getFolderName(), $victim->getName());
				PluginUtils::playSound($victim, 'mob.villager.idle', 1, 1);
				$victim->setGamemode(3);
				$victim->addEffect(new EffectInstance(Effect::getEffect(Effect::BLINDNESS), 1, 1));
				$victim->addTitle('§cYou dead', '', 20, 20, 20);
				ArenaManager::sendSpectatorOptions($victim);
				if ($assassin !== null) {
					$formManager->sendPlayAgain($victim, "§b{$assassin->getName()} §7has killed you.");
					foreach ($victim->getLevel()->getPlayers() as $player) {
						$player->sendMessage(SkyWars::LOG_PREFIX . "§a{$victim->getName()} has killed by {$assassin->getName()}!");
					}
				} else {
					$formManager->sendPlayAgain($victim, $deathCause);
					foreach ($victim->getLevel()->getPlayers() as $player) {
						$player->sendMessage(SkyWars::LOG_PREFIX . "§a{$victim->getName()} has dead!");
					}
				}
			} else {
				$victim->teleport(Position::fromObject(Vector3::fromString((string)ArenaManager::getArenaSettings($victim->getLevel()->getFolderName())->get('respawn'))));
			}
		} else {
			$victim->teleport(Position::fromObject(Vector3::fromString((string)ArenaManager::getArenaSettings($victim->getLevel()->getFolderName())->get('respawn'))));
		}
	}

	/**
	 * @param PlayerDropItemEvent $event
	 */
	public function onDrop(PlayerDropItemEvent $event)
	{
		if (!ArenaManager::isValidArena($event->getPlayer()->getLevel()->getFolderName())) {
			return;
		}
		if (SkyWars::getInstance()->isConfigurator($event->getPlayer())){
			return;
		}
		switch (ArenaManager::getArenaCycle($event->getPlayer()->getLevel()->getFolderName())){
			case Arena::CYCLE_STARTING:
			case Arena::CYCLE_HUB:
			case Arena::CYCLE_ENDING:
				$event->setCancelled(true);
				break;
			default:
				$event->setCancelled(false);
		}
	}

	/**
	 * @param BlockBreakEvent $event
	 */
	public function onBreak(BlockBreakEvent $event)
	{
		if (!ArenaManager::isValidArena($event->getPlayer()->getLevel()->getFolderName())) {
			return;
		}
		if (SkyWars::getInstance()->isConfigurator($event->getPlayer())){
			return;
		}
		switch (ArenaManager::getArenaCycle($event->getPlayer()->getLevel()->getFolderName())){
			case Arena::CYCLE_STARTING:
			case Arena::CYCLE_HUB:
			case Arena::CYCLE_ENDING:
				$event->setCancelled(true);
				break;
			default:
				$event->setCancelled(false);
		}
	}

	/**
	 * @param PlayerGameModeChangeEvent $event
	 */
	public function onGamemodeChange(PlayerGameModeChangeEvent $event){
		if (!ArenaManager::isValidArena($event->getPlayer()->getLevel()->getFolderName())) {
			return;
		}
		if (SkyWars::getInstance()->isConfigurator($event->getPlayer())){
			return;
		}
		if ($event->getNewGamemode() === Player::SPECTATOR){
			ArenaManager::removePlayer($event->getPlayer()->getLevel()->getFolderName(),$event->getPlayer()->getName());
		}
	}

	/**
	 * @param PlayerInteractEvent $event
	 */
	public function onInteract(PlayerInteractEvent $event)
	{
		if (!ArenaManager::isValidArena($event->getPlayer()->getLevel()->getFolderName())) {
			return;
		}
		$player = $event->getPlayer();
		if ($event->getBlock()->getId() === Block::CHEST) {
			switch (ArenaManager::getArenaCycle($event->getPlayer()->getLevel()->getFolderName())){
				case Arena::CYCLE_STARTING:
				case Arena::CYCLE_HUB:
				case Arena::CYCLE_ENDING:
					$event->setCancelled(true);
					break;
				default:
					$event->setCancelled(false);
			}
		}
		if ($event->getItem()->getId() === Item::BOW && $event->getItem()->getCustomName() === "§bKits\n§7SkyWars") {
			FormManager::sendKitsForm($player);
		} elseif ($event->getItem()->getId() === Item::BLAZE_POWDER && $event->getItem()->getCustomName() === "§5Chest Vote\n§7SkyWars") {
			if (!$event->getPlayer()->hasPermission('sw.vote.gamemode')) {
				$event->getPlayer()->sendMessage(SkyWars::LOG_PREFIX . '§aYou can\'t access to this feature.');
				return;
			}
			FormManager::sendInsane($event->getPlayer());
		} elseif ($event->getItem()->getId() === Item::IRON_DOOR && $event->getItem()->getCustomName() === "§cExit\n§7SkyWars") {
			SkyWars::getBossBar()->hideFrom($player);
			$player->setImmobile(false);
			ArenaManager::clearAll($player);
			ArenaManager::removePlayer($player->getLevel()->getFolderName(),$player->getName());
			ArenaManager::removeSpectator($player->getLevel()->getFolderName(),$player->getName());
			$event->getPlayer()->teleport(Server::getInstance()->getDefaultLevel()->getSafeSpawn());
			$event->getPlayer()->sendMessage(SkyWars::LOG_PREFIX . '§7Leaving game...');
		}
	}

	/**
	 * @param PlayerMoveEvent $event
	 */
	public function onMove(PlayerMoveEvent $event)
	{

		if (!ArenaManager::isValidArena($event->getPlayer()->getLevel()->getFolderName())) {
			return;
		}
		$cnf = ArenaManager::getArenaSettings($event->getPlayer()->getLevel()->getFolderName());
		if ($cnf->get('isEnabled') === false){
			return;
		}
		$minVoid = explode(',',$cnf->get('minVoid'))[1];
		switch (ArenaManager::getArenaCycle($event->getPlayer()->getLevel()->getFolderName())){
			case Arena::CYCLE_HUB:
				if ($event->getPlayer()->getY() <= $minVoid + 1) {
					$event->getPlayer()->teleport(ArenaManager::getFreeSlot($event->getPlayer()->getLevel()->getFolderName()));
				}
				break;
			case Arena::CYCLE_STARTING:
				if ($event->getPlayer()->getY() <= $minVoid + 1) {
					$event->getPlayer()->teleport(ArenaManager::getFreeSlot($event->getPlayer()->getLevel()->getFolderName()));
				}
				break;
			case Arena::CYCLE_GAME:
				if ($event->getPlayer()->getY() <= $minVoid + 1) {
					$this->adaptableDeath($event->getPlayer(), '§eYou have fallen to void');
				}
				break;
			case Arena::CYCLE_ENDING:
				if ($event->getPlayer()->getY() <= $minVoid + 1) {
					$event->getPlayer()->teleport(Position::fromObject(Vector3::fromString((string)$cnf->get('respawn'))));
				}
				break;
		}
	}
}