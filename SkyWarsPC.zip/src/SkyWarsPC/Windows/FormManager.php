<?php

/**
 * Copyright 2020-2022 LiTEK
 *      ____  _        __        __
 *    / ___|| | ___   \ \      / /_ _ _ __ ___
 *   \___ \| |/ / | | \ \ /\ / / _` | '__/ __|
 *   ___) |   <| |_| |\ V  V / (_| | |  \__ \
 * |____/|_|\_\\__, | \_/\_/ \__,_|_|  |___/
 *             |___/
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
declare(strict_types=1);

namespace SkyWarsPC\Windows;


use pocketmine\Player;
use pocketmine\scheduler\Task;
use pocketmine\Server;
use SkyWarsPC\Arena\Arena;
use SkyWarsPC\Arena\ArenaManager;
use SkyWarsPC\SkyWars;
use SkyWarsPC\Windows\elements\Button;
use SkyWarsPC\Windows\elements\Image;
use SkyWarsPC\Windows\forms\MenuForm;

class FormManager
{
	public static function sendGameInformation(Player $player): void
	{
		$player->sendForm(new MenuForm(SkyWars::PREFIX, 'Join now to ' . SkyWars::PREFIX . "\n§7Skywars is a multiplayer PvP game where each player starts off on a separate island \nand tries to battle each other like in PvP. \nThe main goal is to be the last person or team alive to win. \nOften there is a middle, larger island that contains chests with better loot.",
			[new Button('§aGames', new Image('textures/ui/controller_glyph_color', Image::TYPE_PATH))],
			static function (Player $player, Button $selected): void {
				if ($selected->getValue() === 0) {
					self::sendGamesList($player);
				}
			}));
	}

	public static function sendGamesList(Player $player): void
	{
		$player->sendForm(new MenuForm(SkyWars::PREFIX, '§7Select a game:',
			self::getGamesButtons(),
			static function (Player $player, Button $selected): void {
				$transform = explode("\n", $selected->getText());
				$arena = substr($transform[0], 3);
				var_dump($arena);
				switch (ArenaManager::getArenaCycle($arena)) {
					case Arena::CYCLE_GAME:
						$player->sendMessage(SkyWars::LOG_PREFIX . '§cArena is full!');
						break;
					case Arena::CYCLE_ENDING:
						$player->sendMessage(SkyWars::LOG_PREFIX . '§cArena is restarting!');
						break;
					case Arena::CYCLE_HUB:
					case Arena::CYCLE_STARTING:
						ArenaManager::joinArena($player, $arena);
						break;
					default:
						$player->sendMessage(SkyWars::LOG_PREFIX . '§cArena disabled!');
						break;
				}
			}));
	}

	private static function getGamesButtons(): array
	{
		$buttons = [];
		foreach (ArenaManager::getAllArenas() as $arena) {
			if (Server::getInstance()->getLevelByName($arena) !== null){
				$buttons[] = new Button('§8' .$arena."\n" . '§7Status:§7 ' . ArenaManager::getArenaStatus($arena) . ' §7Playing: §b' . ArenaManager::getNumberOfPlayers(Server::getInstance()->getLevelByName($arena)));
			}
		}
		return $buttons;
	}


	public function sendPlayAgain(Player $player, string $deathCause): void
	{
		SkyWars::getInstance()->getScheduler()->scheduleDelayedTask(new class($player, $deathCause) extends Task {
			/**
			 * @var Player
			 */
			private $player;

			/**
			 * @var string
			 */
			private $deathCause;


			public function __construct(Player $player, string $deathCause)
			{
				$this->player = $player;
				$this->deathCause = $deathCause;
			}

			public function onRun(int $currentTick): void
			{
				$this->player->sendForm(new MenuForm('§aPlay Again?', "§7Find a new game?\n§e{$this->deathCause}",
					[new Button('§aPlay again', new Image('textures/ui/New_confirm_Hover', Image::TYPE_PATH)),
						new Button('§8Return to lobby', new Image('textures/ui/NetherPortalMirror', Image::TYPE_PATH)),
						new Button('§8Spectate', new Image('textures/items/ender_eye', Image::TYPE_PATH))],
					function (Player $player, Button $selected): void {
						if (ArenaManager::isValidArena($player->getLevel()->getFolderName())) {
							switch ($selected->getValue()) {
								case 0:
									if (ArenaManager::searchAvailableArena() !== null) {
										$player->setGamemode(0);
										$player->setFood(20.0);
										$player->setHealth(20.0);
										$player->getInventory()->clearAll(true);
										$player->getArmorInventory()->clearAll(true);
										$player->removeAllEffects();
										ArenaManager::removePlayer($player->getLevel()->getFolderName(), $player->getName());
										ArenaManager::removeSpectator($player->getLevel()->getFolderName(), $player->getName());
										ArenaManager::joinArena($player, ArenaManager::searchAvailableArena());
									} else {
										$player->sendMessage(SkyWars::LOG_PREFIX . '§cSorry, there are not available arenas.');
									}
									break;
								case 1:
									ArenaManager::removePlayer($player->getLevel()->getFolderName(),$player->getName());
									ArenaManager::removeSpectator($player->getLevel()->getFolderName(),$player->getName());
									$player->setGamemode(0);
									$player->setFood(20.0);
									$player->setHealth(20.0);
									$player->getInventory()->clearAll(true);
									$player->getArmorInventory()->clearAll(true);
									$player->removeAllEffects();
									$player->teleport(Server::getInstance()->getDefaultLevel()->getSafeSpawn());
									$player->sendMessage(SkyWars::LOG_PREFIX . '§7Leaving game...');
									break;
								case 2:
								default:
									ArenaManager::sendSpectatorOptions($player);
									break;
							}
						} else {
							$player->sendMessage(SkyWars::LOG_PREFIX . '§cYou are not in arena.');
						}
					}));
			}
		}, 40);
	}

	public static function sendInsane(Player $player): void
	{
		$player->sendForm(new MenuForm(SkyWars::PREFIX . ' §5OP Chests', "§5OP Chests§7 supplies armor ranging from iron to §bdiamond§7 in chests, and swords being either stone or §bdiamond§7 with various §6enchantments§7.\nYou have access to §5OP§7 Kits. Teaming is not allowed. §aDo you want to play with §5OP Chests§7?",
			[new Button('§aVote for OP Chests!', new Image('textures/ui/fire_resistance_effect', Image::TYPE_PATH))], static function (Player $player, Button $selected): void {
				if ($selected->getValue() === 0) {
					$player->sendMessage(SkyWars::LOG_PREFIX . '§aYou have voted for play with §5OP Chests.');
					ArenaManager::setOPChests($player->getLevel()->getFolderName(), true);
					foreach ($player->getLevel()->getPlayers() as $playerInGame) {
						$playerInGame->sendMessage(SkyWars::LOG_PREFIX . "§6{$player->getName()} §7has voted for OP Chests!");
					}
				}
			}));
	}


	public static function sendKitsForm(Player $player): void
	{
		$player->sendForm(new MenuForm('§8Kit Selection','§7Select a kit to use:', [
			new Button("§aBuilder\n§e20 bricks, Chain chestplate", new Image('textures/items/brick',Image::TYPE_PATH)),
			new Button("§aChef\n§eStone sword, 3 steak", new Image('textures/items/porkchop_cooked',Image::TYPE_PATH)),
			new Button("§aTank\n§eIron chestplate, Iron boots", new Image('textures/items/iron_chestplate',Image::TYPE_PATH)),
			new Button("§aHealer\n§eGolden Apple", new Image('textures/items/apple_golden',Image::TYPE_PATH))
		],static function(Player $player, Button $selected): void {
			switch ($selected->getValue()){
				case 0:
					if (!$player->hasPermission('sw.kit.builder')){
						$player->sendMessage(SkyWars::LOG_PREFIX . '§cUhm, you don\'t have permission to use this kit.');
						return;
					}
					ArenaManager::setKit($player,'builder',$player->getLevel()->getFolderName());
					$player->sendMessage(SkyWars::LOG_PREFIX . '§aYou have selected §eBuilder§a kit.');
					break;
				case 1:
					if (!$player->hasPermission('sw.kit.chef')){
						$player->sendMessage(SkyWars::LOG_PREFIX . '§cUhm, you don\'t have permission to use this kit.');
						return;
					}
					ArenaManager::setKit($player,'chef',$player->getLevel()->getFolderName());
					$player->sendMessage(SkyWars::LOG_PREFIX . '§aYou have selected §eChef§a kit.');
					break;
				case 2:
					if (!$player->hasPermission('sw.kit.tank')){
						$player->sendMessage(SkyWars::LOG_PREFIX . '§cUhm, you don\'t have permission to use this kit.');
						return;
					}
					ArenaManager::setKit($player,'tank',$player->getLevel()->getFolderName());
					$player->sendMessage(SkyWars::LOG_PREFIX . '§aYou have selected §eTank§a kit.');
					break;
				case 3:
					if (!$player->hasPermission('sw.kit.healer')){
						$player->sendMessage(SkyWars::LOG_PREFIX . '§cUhm, you don\'t have permission to use this kit.');
						return;
					}
					ArenaManager::setKit($player,'healer',$player->getLevel()->getFolderName());
					$player->sendMessage(SkyWars::LOG_PREFIX . '§aYou have selected §eHealer§a kit.');
					break;
				default:
					return;
			}
		}));
	}
}