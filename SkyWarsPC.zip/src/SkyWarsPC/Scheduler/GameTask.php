<?php

/**
 * Copyright 2020-2022 LiTEK
 *      ____  _        __        __
 *    / ___|| | ___   \ \      / /_ _ _ __ ___
 *   \___ \| |/ / | | \ \ /\ / / _` | '__/ __|
 *   ___) |   <| |_| |\ V  V / (_| | |  \__ \
 * |____/|_|\_\\__, | \_/\_/ \__,_|_|  |___/
 *             |___/
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
declare(strict_types=1);

namespace SkyWarsPC\Scheduler;


use pocketmine\block\Block;
use pocketmine\math\Vector3;
use pocketmine\network\mcpe\protocol\ActorEventPacket;
use pocketmine\Player;
use pocketmine\scheduler\Task;
use pocketmine\Server;
use SkyWarsPC\Arena\Arena;
use SkyWarsPC\Arena\ArenaManager;
use SkyWarsPC\Data\Database;
use SkyWarsPC\Kit\KitManager;
use SkyWarsPC\MathUtils\Time;
use SkyWarsPC\SkyWars;
use SkyWarsPC\Util\chest\ChestContent;
use SkyWarsPC\Util\PluginUtils;

class GameTask extends Task
{

	/**
	 * @var Database
	 */
	private $database;

	public function __construct()
	{
		$this->database = new Database();
	}

	/**
	 * @inheritDoc
	 */
	public function onRun(int $currentTick): void
	{
		if (ArenaManager::getAllArenas() === null) {
			return;
		}
		foreach (ArenaManager::getAllArenas() as $allArena) {
			$startTime = ArenaManager::getTime($allArena, 'startTime');
			$gameTime = ArenaManager::getTime($allArena, 'gameTime');
			$endTime = ArenaManager::getTime($allArena, 'endTime');
			$arena = Server::getInstance()->getLevelByName($allArena);
			if (!Server::getInstance()->isLevelLoaded($allArena)) {
				return;
			}
			$players = $arena->getPlayers();
			switch (ArenaManager::getArenaCycle($allArena)) {
				case Arena::CYCLE_HUB:
					if (count($players) < 2) {
						ArenaManager::setTime($allArena, 'startTime', 15);
						ArenaManager::setTime($allArena, 'gameTime', 1200);
						ArenaManager::setTime($allArena, 'endTime', 5);
						foreach ($players as $player) {
							SkyWars::getBossBar()->updateFor($player, PluginUtils::centerLine(SkyWars::PREFIX . '   §aWaiting players...    §aArena:§7 ' . $allArena), 100);
							$player->setXpLevel((int)$startTime);
						}
					} else {
						ArenaManager::setArenaCycle($allArena, Arena::CYCLE_STARTING);
					}
					break;
				case Arena::CYCLE_STARTING:
					if (count($players) <= 1) {
						ArenaManager::setArenaCycle($allArena, Arena::CYCLE_HUB);
					}
					if ($startTime <= 0) {
						foreach ($players as $player) {
							$player->setImmobile(false);
						}
						ArenaManager::setArenaCycle($allArena, Arena::CYCLE_GAME);
					}
					foreach ($players as $player) {
						PluginUtils::playSound($player, 'note.bit', 1, 1);
						SkyWars::getBossBar()->updateFor($player, PluginUtils::centerLine(SkyWars::PREFIX . '   §aStarting...    §aArena:§7 ' . $allArena), 100);
						if ($startTime >= 0) {
							$player->setXpLevel((int)$startTime);
						}
						if (count($players) === ArenaManager::getMaxSlots(Server::getInstance()->getLevelByName($allArena)) - 1){
							$player->setXpLevel(0);
							ArenaManager::setArenaCycle($allArena, Arena::CYCLE_GAME);
						}
					}
					$startTime--;
					ArenaManager::setTime($allArena, 'startTime', (int)$startTime);
					break;
				case Arena::CYCLE_GAME:
					if ($gameTime === 1200) {
						if (ArenaManager::getOPChests($allArena)) {
							ChestContent::refillChests(Server::getInstance()->getLevelByName($allArena), true);
						} else {
							ChestContent::refillChests(Server::getInstance()->getLevelByName($allArena), false);
						}
						foreach ($players as $player) {
							$block = $player->getLevel()->getBlock(new Vector3($player->x, $player->y - 0.5, $player->z));
							if ($block->getId() === Block::GLASS) {
								$player->getLevel()->setBlock(new Vector3($player->x, $player->y - 0.5, $player->z), Block::get(Block::AIR));
							}
							$player->broadcastEntityEvent(ActorEventPacket::CONSUME_TOTEM);
							PluginUtils::playSound($player, 'conduit.activate', 1, 1);
							$player->addTitle(SkyWars::PREFIX, '§bArena: ' . $allArena);
							$player->getInventory()->clearAll(true);
							$player->getArmorInventory()->clearAll(true);
							$player->removeAllEffects();
	                      	$player->setScale(1);
	                     	$player->setAllowFlight(false);
		                    $player->setFlying(false);
							$player->setHealth(20);
							$player->setFood(20);
							foreach (ArenaManager::getKits($allArena) as $index => $array) {
								foreach ($array as $playerKit => $kit) {
									$parsedPlayerKit = Server::getInstance()->getPlayer($playerKit);
									KitManager::acquireKit($parsedPlayerKit, $kit);
								}
							}
						}
					}
					if ($gameTime === 600) {
						if (ArenaManager::getOPChests($allArena)) {
							ChestContent::refillChests(Server::getInstance()->getLevelByName($allArena), true);
						} else {
							ChestContent::refillChests(Server::getInstance()->getLevelByName($allArena), false);
						}
						foreach ($players as $player) {
							$player->sendMessage(SkyWars::LOG_PREFIX . '§aChests have been refilled!');
						}
					}
					$refill = $gameTime >= 600 ? Time::calculateTime((int)round($gameTime / 2)) : 0;
					foreach ($players as $player) {
						SkyWars::getBossBar()->updateFor($player, PluginUtils::centerLine('§bTime: §7' . Time::calculateTime($gameTime) . '    §bPlayers: §7' . count(ArenaManager::getPlayers($allArena)) . '    §bRefill in: ' . $refill));
						if (count(ArenaManager::getPlayers($allArena)) === 1) {
							if ($player->getGamemode() === Player::SURVIVAL && $player->isAlive()) {
								$player->addTitle(SkyWars::PREFIX, '§aYou won');
								$this->database->setWonMatch($player->getName());
								PluginUtils::playSound($player, 'mob.vindicator.celebrate', 1, 1);
								ArenaManager::setArenaCycle($allArena, Arena::CYCLE_ENDING);
							}
						}
					}
					if ($gameTime === 0 && count(ArenaManager::getPlayers($allArena)) >= 2) {
						foreach ($players as $player) {
							if ($player->getGamemode() === Player::SURVIVAL && $player->isAlive()) {
								$player->addTitle('§cGame Over');
								ArenaManager::setArenaCycle($allArena, Arena::CYCLE_ENDING);
							}
						}
					}
					$gameTime--;
					ArenaManager::setTime($allArena, 'gameTime', $gameTime);
					break;
				case Arena::CYCLE_ENDING:
					foreach ($players as $player) {
						PluginUtils::playSound($player, 'note.bit', 1, 1);
						$player->sendTip(SkyWars::LOG_PREFIX . '§5Ending in ' . $endTime);
					}
					if ($endTime === 0) {
						foreach ($players as $player) {
							SkyWars::getBossBar()->hideFrom($player);
							$this->clearAll($player);
							$player->teleport(Server::getInstance()->getDefaultLevel()->getSafeSpawn());
						}
						ArenaManager::resetArena($allArena);
						self::reloadArena($allArena);
					}
					$endTime--;
					ArenaManager::setTime($allArena, 'endTime', $endTime);
					break;
			}

		}
	}

	public static function reloadArena(string $arena): void
	{
		if ($arena !== null) {
			$cnf = ArenaManager::getArenaSettings($arena);
			ArenaManager::setTime($arena, 'gameTime', 20 * 60);
			ArenaManager::setTime($arena, 'startTime', 15);
			ArenaManager::setTime($arena, 'endTime', 5);
			$cnf->set('OP', false);
			$cnf->set('players', []);
			$cnf->set('spectators', []);
			$cnf->set('kits', []);
			$cnf->save();
			ArenaManager::setArenaCycle($arena, Arena::CYCLE_HUB);
		}
	}

	private function clearAll(Player $player)
	{
		$player->getArmorInventory()->clearAll(true);
		$player->getInventory()->clearAll(true);
		$player->removeAllEffects();
		$player->setFood(20.0);
		$player->setHealth(20.0);
		$player->setGamemode(0);
	}
}