<?php

/**
 * Copyright 2020-2022 LiTEK
 *      ____  _        __        __
 *    / ___|| | ___   \ \      / /_ _ _ __ ___
 *   \___ \| |/ / | | \ \ /\ / / _` | '__/ __|
 *   ___) |   <| |_| |\ V  V / (_| | |  \__ \
 * |____/|_|\_\\__, | \_/\_/ \__,_|_|  |___/
 *             |___/
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
declare(strict_types=1);
namespace SkyWarsPC\Scheduler;


use pocketmine\scheduler\Task;
use pocketmine\Server;
use SkyWarsPC\Arena\ArenaManager;
use SkyWarsPC\Data\Database;
use SkyWarsPC\Entity\types\JoinEntity;
use SkyWarsPC\Entity\types\TopsEntity;
use SkyWarsPC\SkyWars;

class UpdateJoinEntity extends Task
{

	/**
	 * @inheritDoc
	 */
	public function onRun(int $currentTick): void
	{
		foreach (Server::getInstance()->getDefaultLevel()->getEntities() as $entity) {
			if ($entity instanceof JoinEntity){
				$entity->setNameTagAlwaysVisible(true);
				$entity->setNameTagVisible(true);
				$entity->setNameTag($this->getNametag());
			} elseif ($entity instanceof TopsEntity){
				$entity->setNameTagAlwaysVisible(true);
				$entity->setNameTagVisible(true);
				$entity->setNameTag($this->getTops());
			}
		}
	}

	public function getNametag(): string
	{
		return '§e§l» CLICK TO PLAY «§r' . "\n" . SkyWars::PREFIX . "\n" . "§f{$this->getTotalPlayersInGame()} §ePlayers\n\n";
	}


	private function getTotalPlayersInGame(): int
	{
		$totalPlayers = [];
		foreach (ArenaManager::getAllArenas() as $arena) {
			if (Server::getInstance()->getLevelByName($arena) !== null) {
				foreach (Server::getInstance()->getLevelByName($arena)->getPlayers() as $player) {
					$totalPlayers[] = $player;
				}
			}
		}
		return count($totalPlayers);
	}

	private function getTops(): string
	{
		$database = new Database();
		return $database->getTops();
	}
}