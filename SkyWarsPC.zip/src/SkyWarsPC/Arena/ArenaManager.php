<?php

/**
 * Copyright 2020-2022 LiTEK
 *      ____  _        __        __
 *    / ___|| | ___   \ \      / /_ _ _ __ ___
 *   \___ \| |/ / | | \ \ /\ / / _` | '__/ __|
 *   ___) |   <| |_| |\ V  V / (_| | |  \__ \
 * |____/|_|\_\\__, | \_/\_/ \__,_|_|  |___/
 *             |___/
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
declare(strict_types=1);
namespace SkyWarsPC\Arena;

use pocketmine\item\Item;
use pocketmine\level\Level;
use pocketmine\level\Position;
use pocketmine\Player;
use pocketmine\Server;
use pocketmine\utils\Config;
use SkyWarsPC\MathUtils\Vector3;
use SkyWarsPC\Scheduler\GameTask;
use SkyWarsPC\SkyWars;
use SkyWarsPC\Util\ArenaUID;
use SkyWarsPC\Util\PluginUtils;
use SkyWarsPC\Util\RarArchiver;

class ArenaManager
{
	use ArenaProperties;

	/**
	 * @param Level $levelName
	 * @return bool
	 */
	public static function isValidWorld(Level $levelName): bool
	{
		return SkyWars::getInstance()->getServer()->isLevelGenerated($levelName->getFolderName());
	}


	public static function getArenaSettings(string $levelName): ?Config
	{
		if ($levelName !== null) {
			return new Config(SkyWars::getInstance()->getDataFolder() . 'arenas' . DIRECTORY_SEPARATOR . "{$levelName}.yml");
		}
	}

	/**
	 * @param Player $player
	 * @param string $arenaName
	 * @param Level $levelName
	 */
	public static function createArena(Player $player, string $arenaName, Level $levelName): void
	{
			Server::getInstance()->loadLevel($levelName->getFolderName());
			$player->teleport($levelName->getSafeSpawn());
			$newArena = new Arena([
				'arenaName' => $arenaName,
				'levelName' => $levelName->getFolderName(),
				'arenaID' => ArenaUID::generateUniqueID(10),
				'maxSlots' => 8,
				'isEnabled' => false
			]);
			$newArena->saveFactoryData();
			SkyWars::getInstance()->configurators[] = $player->getName();
			$player->sendMessage(SkyWars::LOG_PREFIX . '§aArena ' . $arenaName . "§e ({$levelName->getFolderName()})§a created.\nPlease complete the factory data.\n§7Write §ehelp §7in the chat for help.");
	}

	/**
	 * @param Player $player
	 * @param Level $levelName
	 */
	public static function reconfigureArena(Player $player, Level $levelName): void
	{
		if (self::isValidArena($levelName->getFolderName())) {
			Server::getInstance()->loadLevel($levelName->getFolderName());
			$player->teleport($levelName->getSafeSpawn());
			SkyWars::getInstance()->configurators[] = $player->getName();
			$player->sendMessage(SkyWars::LOG_PREFIX . '§aArena ' . $levelName->getName() . "§e ({$levelName->getName()})§a is being configurated.\nPlease add the new factory data.\n§7Write §ehelp §7in the chat for help.");
		} else {
			$player->sendMessage(SkyWars::LOG_PREFIX . '§cUhm, that world doesn\'t exists.');
		}
	}

	/**
	 * @param Player $player
	 * @param $data
	 * @param string $datatype
	 * @param int $index
	 */
	public static function setArenaDataIndex(Player $player, $data, string $datatype, int $index = 0): void
	{
		$arenaConfig = self::getArenaSettings($player->getLevel()->getFolderName());
		if ($arenaConfig === null){
			return;
		}
		if (self::isValidArena($player->getLevel()->getFolderName())) {
			switch ($datatype) {
				case 'slots':
					$arenaConfig->set('maxSlots', $data);
					$arenaConfig->save();
					break;
				case 'void':
					$arenaConfig->set('minVoid', $data);
					$arenaConfig->save();
					break;
				case 'status':
					$arenaConfig->set('isEnabled', $data);
					$arenaConfig->save();
					break;
				case 'spawn':
					$arenaConfig->set('spawn-' . $index, $data);
					$arenaConfig->save();
					break;
				case 'respawn':
					$arenaConfig->set('respawn', $data);
					$arenaConfig->save();
					break;
				case 'lobby':
					$arenaConfig->set('lobby', $data);
					$arenaConfig->save();
					break;
				default:
					SkyWars::getInstance()->getLogger()->debug('Unknown datatype or unknown index for arena.');
					break;
			}

		}
	}

	/**
	 * @param Level $levelName
	 * @return bool|mixed
	 */
	public static function getMaxSlots(Level $levelName)
	{
		$arenaConfig = self::getArenaSettings($levelName->getFolderName());
		return $arenaConfig->get('maxSlots');
	}

	public static function getArenaName(string $levelName)
	{
		$arenaConfig = self::getArenaSettings($levelName);
		return $arenaConfig->get('arenaName');
	}

	/**
	 * @param string $levelName
	 * @return bool
	 */
	public static function isValidArena(string $levelName): bool
	{
		$arenas = scandir(SkyWars::getInstance()->getDataFolder() . 'arenas' . DIRECTORY_SEPARATOR);
		foreach ($arenas as $arena => $value) {
			$path = realpath(SkyWars::getInstance()->getDataFolder() . 'arenas' . DIRECTORY_SEPARATOR . $value);
			if (!is_dir($path)) {
				if ("$levelName.yml" === $value) {
					return true;
					break;
				}
			} else if ($value !== '.' && $value !== '..') {
				self::isValidArena($levelName);
			}
		}
		return false;
	}


	/**
	 * @return array
	 */
	public static function getAllArenas(): array
	{
		$arenas = [];
		if ($handle = opendir(SkyWars::getInstance()->getDataFolder() . 'arenas')) {
			while (false !== ($entry = readdir($handle))) {
				if ($entry !== '.' && $entry !== '..') {
					$parsedArena = explode('.',basename($entry));
					$arenas[] = $parsedArena[0];
				}
			}
			closedir($handle);
		}
		return array_filter($arenas);
	}

	/**
	 * @param string $arena
	 */
	public static function deleteArena(string $arena): void
	{
		if (self::isValidArena($arena) && is_file(SkyWars::getInstance()->getDataFolder() . 'compressed' . DIRECTORY_SEPARATOR . "$arena.zip")) {
			unlink(SkyWars::getInstance()->getDataFolder() . 'arenas' . DIRECTORY_SEPARATOR . "$arena.yml");
			unlink(SkyWars::getInstance()->getDataFolder() . 'compressed' . DIRECTORY_SEPARATOR . "$arena.zip");
		}
	}

	/**
	 * @return void
	 * Function to load skywars arenas.
	 */
	public static function loadArenas(): void
	{
		foreach (self::getAllArenas() as $arena) {
			SkyWars::getInstance()->getLogger()->info('§aArena:' . $arena . ' §aloaded');
			Server::getInstance()->loadLevel($arena);
			GameTask::reloadArena($arena);
		}
	}

	/**
	 * @param string $arena
	 * @param string $type
	 * @return bool|mixed
	 */
	public static function getTime(string $arena, string $type){
		$cnf = self::getArenaSettings($arena);
		return $cnf->get($type);
	}

	/**
	 * @param string $arena
	 * @param string $type
	 * @param int $time
	 */
	public static function setTime(string $arena, string $type, int $time): void
	{
		$cnf = self::getArenaSettings($arena);
		$cnf->set($type,$time);
		$cnf->save();
	}

	/**
	 * @param string $levelName
	 */
	public static function compressArena(string $levelName): void
	{
		$level = Server::getInstance()->getLevelByName($levelName);
		if ($level !== null) {
			$level->save(true);
			$levelPath = SkyWars::getInstance()->getServer()->getDataPath() . 'worlds' . DIRECTORY_SEPARATOR . $level->getFolderName();
			$zipPath = SkyWars::getInstance()->getDataFolder() . 'compressed' . DIRECTORY_SEPARATOR . $level->getFolderName() . '.zip';

			$zip = new \ZipArchive();

			if (is_file($zipPath)) {
				unlink($zipPath);
			}

			$zip->open($zipPath, \ZipArchive::CREATE | \ZipArchive::OVERWRITE);
			$files = new \RecursiveIteratorIterator(new \RecursiveDirectoryIterator(realpath($levelPath)), \RecursiveIteratorIterator::LEAVES_ONLY);

			/** @var \SplFileInfo $file */
			foreach ($files as $file) {
				if ($file->isFile()) {
					$filePath = $file->getPath() . DIRECTORY_SEPARATOR . $file->getBasename();
					$localPath = substr($filePath, strlen(SkyWars::getInstance()->getServer()->getDataPath() . 'worlds'));
					$zip->addFile($filePath, $localPath);
				}
			}

			$zip->close();
		}
	}

	/**
	 * @param Player $player
	 * @return bool
	 */
	public static function isPlaying(Player $player): bool
	{
		foreach (self::getAllArenas() as $arenaName) {
			if ($player->getLevel()->getFolderName() === $arenaName) {
				return true;
			}
		}
		return false;
	}


	/**
	 * @param string $arena
	 * @return string
	 */
	public static function getArenaCycle(string $arena): string
	{
		$config = new Config(SkyWars::getInstance()->getDataFolder() . 'arenas/' . $arena . '.yml', Config::YAML);
		return (string)$config->get('arenaCycle');
	}


	/**
	 * @param string $arena
	 * @param int $cycle
	 */
	public static function setArenaCycle(string $arena, int $cycle): void
	{
		$config = new Config(SkyWars::getInstance()->getDataFolder() . 'arenas/' . $arena . '.yml', Config::YAML);
		$config->set('arenaCycle', $cycle);
		$config->save();
	}

	/**
	 * @param string $arena
	 * @param bool $status
	 */
	public static function setOPChests(string $arena, bool $status): void
	{
		$config = new Config(SkyWars::getInstance()->getDataFolder() . 'arenas/' . $arena . '.yml', Config::YAML);
		$config->set('OP', $status);
		$config->save();
	}

	/**
	 * @param string $arena
	 * @return bool
	 */
	public static function getOPChests(string $arena): bool
	{
		$config = new Config(SkyWars::getInstance()->getDataFolder() . 'arenas/' . $arena . '.yml', Config::YAML);
		return (bool)$config->get('OP');
	}

	public static function getAlive(string $arena)
	{
		$players = [];
		foreach (Server::getInstance()->getLevelByName($arena)->getPlayers() as $player) {
			if (self::isPlaying($player) && $player->getGamemode() !== Player::SPECTATOR) {
				array_push($players, $player->getName());
			}
		}
		return $players;
	}

	/**
	 * @param Level $arena
	 * @return int
	 */
	public static function getNumberOfPlayers(Level $arena)
	{
		if (self::isValidArena($arena->getName())) {
			return count($arena->getPlayers());
		}
	}



	public static function getMinVoid(string $arena)
	{
		$config = self::getArenaSettings($arena);
		$parse = $config->get('minVoid');
		$minVoid = explode(',', $parse);
		return $minVoid[1];
	}


	public static function resetArena(string $arena): bool
	{
		if (Server::getInstance()->isLevelLoaded($arena)) {
			Server::getInstance()->unloadLevel(Server::getInstance()->getLevelByName($arena));
		}
		$zipPath = SkyWars::getInstance()->getDataFolder() . 'compressed' . DIRECTORY_SEPARATOR . $arena . '.zip';
		$zipArchive = new \ZipArchive();
		$zipArchive->open($zipPath);
		$zipArchive->extractTo(SkyWars::getInstance()->getServer()->getDataPath() . 'worlds');
		$zipArchive->close();
		Server::getInstance()->loadLevel($arena);
		return true;
	}

	public static function addPlayer(string $arena, string $player): void
	{
		$cnf = self::getArenaSettings($arena);
		if (!$cnf->exists('players')){
			$cnf->set('players',[]);
			$cnf->save();
		}
		if (!in_array($player,self::getPlayers($arena),true)){
			$array_players = self::getPlayers($arena);
			$array_players[] = $player;
			$cnf->set('players',array_unique($array_players));
			$cnf->save();
		}
	}

	public static function removePlayer(string $arena, string $player): void
	{
		$cnf = self::getArenaSettings($arena);
		if (!$cnf->exists('players')){
			$cnf->set('players',[]);
			$cnf->save();
		}
		if (in_array($player,self::getPlayers($arena),true)){
			$array_players = self::getPlayers($arena);
			unset($array_players[array_search($player,$array_players,true)]);
			$cnf->set('players',$array_players);
			$cnf->save();
		}
	}

	public static function getPlayers(string $arena){
		$cnf = self::getArenaSettings($arena);
		if (!$cnf->exists('players')){
			$cnf->set('players',[]);
			$cnf->save();
		}
		return $cnf->get('players');
	}

	public static function addSpectator(string $arena, string $player): void
	{
		$cnf = self::getArenaSettings($arena);
		if (!$cnf->exists('spectators')){
			$cnf->set('spectators',[]);
			$cnf->save();
		}
		if (!in_array($player,self::getSpectators($arena),true)){
			$array_spectators = self::getSpectators($arena);
			$array_spectators[] = $player;
			$cnf->set('spectators',array_unique($array_spectators));
			$cnf->save();
		}
	}

	public static function removeSpectator(string $arena, string $player): void
	{
		$cnf = self::getArenaSettings($arena);
		if (!$cnf->exists('spectators')){
			$cnf->set('players',[]);
			$cnf->save();
		}
		if (in_array($player,self::getSpectators($arena),true)){
			$array_spectators = self::getSpectators($arena);
			unset($array_spectators[array_search($player,$array_spectators,true)]);
			$cnf->set('spectators', array_unique($array_spectators));
			$cnf->save();
		}
	}

	public static function getSpectators(string $arena){
		$cnf = self::getArenaSettings($arena);
		if (!$cnf->exists('spectators')){
			$cnf->set('spectators',[]);
			$cnf->save();
		}
		return $cnf->get('spectators');
	}

	public static function getFreeSlot(string $arena): ?Position
	{
		$level = Server::getInstance()->getLevelByName($arena);
		$maxSlots = self::getMaxSlots($level);
		$playerNum = count(self::getPlayers($arena));
		if ($playerNum <= $maxSlots) {
			if ($level !== null) {
				return Position::fromObject(Vector3::fromString((string)self::getArenaSettings($level->getFolderName())->get('spawn-' . ($playerNum + 1))), $level);
			}
		}
	}

	public static function joinArena(Player $player, string $arena): void
	{
		self::addPlayer($arena,$player->getName());
		$player->teleport(self::getFreeSlot($arena));
		$player->sendMessage(SkyWars::LOG_PREFIX . '§aYou have entered to ' . $arena . ' arena.');
		SkyWars::getBossBar()->showTo($player,PluginUtils::centerText(SkyWars::PREFIX . ' §cRetrieving game data...'));
		$player->addTitle(SkyWars::PREFIX);
		$player->setGamemode(0);
		$player->setHealth(20.0);
		$player->setFood(20.0);
		$player->setFlying(false);
		$player->getInventory()->clearAll(true);
		$player->getArmorInventory()->clearAll(true);
		$player->setImmobile(false);
		self::sendOptions($player);
		foreach (Server::getInstance()->getLevelByName($arena)->getPlayers() as $playerInGame) {
			PluginUtils::playSound($playerInGame,'mob.dolphin.idle',1,1);
			if ($player->getName() !== $playerInGame->getName()) {
				$playerInGame->sendMessage(SkyWars::LOG_PREFIX . '§aPlayer ' . $player->getName() . ' has joined.');
			}
		}
	}

	public static function sendOptions(Player $player): void
	{
		$player->getInventory()->clearAll(true);
		$player->getInventory()->setItem(0, (Item::get(Item::BOW, 0, 1)->setCustomName("§bKits\n§7SkyWars")));
		$player->getInventory()->setItem(1, (Item::get(Item::BLAZE_POWDER, 0, 1)->setCustomName("§5Chest Vote\n§7SkyWars")));
		$player->getInventory()->setItem(8, (Item::get(Item::IRON_DOOR, 0, 1)->setCustomName("§cExit\n§7SkyWars")));
	}

	public static function sendSpectatorOptions(Player $player): void
	{
		$player->getInventory()->clearAll(true);
		$player->getInventory()->setItem(8, (Item::get(Item::IRON_DOOR, 0, 1)->setCustomName("§cExit\n§7SkyWars")));
	}

	public static function getArenaStatus(string $arena): ?string
	{
		$status = self::getArenaCycle($arena);
		switch ($status){
			case Arena::CYCLE_GAME:
				return '§cinGame';
				break;
			case Arena::CYCLE_ENDING:
				return '§5Restarting';
				break;
			case Arena::CYCLE_HUB:
			case Arena::CYCLE_STARTING:
				return '§aWaiting';
				break;
			default:
				return '§4Disabled';
				break;
		}
	}

	/**
	 * @return mixed
	 */
	public static function searchAvailableArena(){
		foreach (self::getAllArenas() as $allArena) {
			$cycle = self::getArenaCycle($allArena);
				switch ($cycle){
					case Arena::CYCLE_HUB:
					case Arena::CYCLE_STARTING:
						return $allArena;
						break;
				}
		}

	}

	public static function clearAll(Player $player): void
	{
		$player->getArmorInventory()->clearAll(true);
		$player->getInventory()->clearAll(true);
		$player->removeAllEffects();
		$player->setFood(20.0);
		$player->setHealth(20.0);
		$player->setGamemode(0);
	}

	/**
	 * @param Player $player
	 * @param string $kit
	 * @param string $arena
	 */
	public static function setKit(Player $player, string $kit, string $arena): void
	{
		$cnf = self::getArenaSettings($arena);
		if (!$cnf->exists('kits')){
			$cnf->set('kits',array());
			$cnf->save();
		}
		$kits = $cnf->get('kits');
		if(is_array($kits)) { //fixed by Josewowgame/ Testng now
			if (!self::findKey($kits,$player->getName())){
				$kits[] = [$player->getName() => $kit];
				$cnf->set('kits',$kits);
				$cnf->save();
			} else {
				$kits[array_search($player->getName(), $kits, true)][$player->getName()] = $kit;
				$cnf->set('kits',$kits);
				$cnf->save();
			}
		} else {
			var_dump($cnf->get('kits'));
		}
	}

	private static function findKey(array $array, $keySearch): bool
	{
		foreach ($array as $key => $item) {
			if ($key === $keySearch) {
				return true;
			}

			if (is_array($item) && self::findKey($item, $keySearch)) {
				return true;
			}
		}
		return false;
	}

	/**
	 * @param string $arena
	 * @return bool|mixed
	 */
	public static function getKits(string $arena){
		$cnf = new Config(SkyWars::getInstance()->getDataFolder() . 'arenas/' . $arena . '.yml', Config::YAML);
		if (!$cnf->exists('kits')){
			$cnf->set('kits',[]);
			$cnf->save();
		}
		return $cnf->get('kits');
	}

}