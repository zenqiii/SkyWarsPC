<?php

/**
 * Copyright 2020-2022 LiTEK
 *      ____  _        __        __
 *    / ___|| | ___   \ \      / /_ _ _ __ ___
 *   \___ \| |/ / | | \ \ /\ / / _` | '__/ __|
 *   ___) |   <| |_| |\ V  V / (_| | |  \__ \
 * |____/|_|\_\\__, | \_/\_/ \__,_|_|  |___/
 *             |___/
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
declare(strict_types=1);
namespace SkyWarsPC\Arena;


use pocketmine\Server;
use SkyWarsPC\Util\ArenaUID;

class Arena
{

	use ArenaProperties;

	public const CYCLE_HUB = 0;
	public const CYCLE_STARTING = 1;
	public const CYCLE_GAME = 2;
	public const CYCLE_ENDING = 3;


	/* @var array */
	private $factoryData;

	/**
	 * Arena constructor.
	 * @param array $factoryData
	 */
	public function __construct(array $factoryData)
	{
		$this->factoryData = $factoryData ?? $this->createBasicFactoryData();
	}

	/**
	 * @return array
	 */
	public function createBasicFactoryData(): array
	{
		$this->factoryData['arenaName'] = $this->arenaName;
		$this->factoryData['levelName'] = $this->levelName;
		$this->factoryData['arenaID'] = ArenaUID::generateUniqueID();
		$this->factoryData['maxSlots'] = 8;
		$this->factoryData['minVoid'] = null;
		$this->factoryData['arenaCycle'] = self::CYCLE_HUB;
		$this->factoryData['startTime'] = 40;
		$this->factoryData['gameTime'] = 20 * 60;
		$this->factoryData['endTime'] = 10;
		$this->factoryData['isEnabled'] = false;
		return $this->factoryData;
	}

	/**
	 * Save default arena data
	 */
	public function saveFactoryData(): void
	{
		$arenaConfig = ArenaManager::getArenaSettings($this->factoryData['levelName']);
		$arenaConfig->setAll($this->factoryData);
		$arenaConfig->save();
	}

}